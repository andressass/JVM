var searchData=
[
  ['javaclass',['javaClass',['../struct_handler.html#a0d23c9897e6fa7293405ac2ba8321efb',1,'Handler::javaClass()'],['../struct_class_table.html#a32e6ffa41523c58f4f9ac382399832dc',1,'ClassTable::javaClass()'],['../struct_frame.html#ac06cb2c272949f9290bca323136f6438',1,'Frame::javaClass()']]]
];
