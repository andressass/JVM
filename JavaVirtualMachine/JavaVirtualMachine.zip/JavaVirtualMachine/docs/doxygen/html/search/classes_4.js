var searchData=
[
  ['handler',['Handler',['../struct_handler.html',1,'']]]
];
