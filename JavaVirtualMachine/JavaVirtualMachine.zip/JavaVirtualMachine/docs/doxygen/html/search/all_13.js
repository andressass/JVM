var searchData=
[
  ['verifyinvokespecial',['verifyInvokeSpecial',['../_m___i_n_s_t_o_b_j_a_n_d_i_n_v_o_k_e_8c.html#aa66c2de6acafae4bc5dbbf717f95f9a5',1,'M_INSTOBJANDINVOKE.c']]],
  ['vmstack',['VMStack',['../struct_v_m_stack.html',1,'VMStack'],['../struct_thread.html#a14942cb194dc5185288e629c6da5ac3a',1,'Thread::vmStack()'],['../_e___j_v_m_8h.html#ae8c207048b4b683e0e66c25d01fa7d00',1,'VMStack():&#160;E_JVM.h']]]
];
