var searchData=
[
  ['magic',['magic',['../structarq_class.html#af2bde90f63d048e444c9437063394b4f',1,'arqClass']]],
  ['major_5fversion',['major_version',['../structarq_class.html#a0aeda33023ba35d892279365630779d3',1,'arqClass']]],
  ['max_5flocals',['max_locals',['../struct_code_attribute.html#a1407b9bddee5eca9e0b0b20fbf1a8f1f',1,'CodeAttribute']]],
  ['max_5fstack',['max_stack',['../struct_code_attribute.html#a61e8f2685ef2bb170d72e402a0e72ca2',1,'CodeAttribute']]],
  ['memoryaddress',['memoryAddress',['../struct_fields_table.html#a5c251342633df2e314a6b88c25f2a604',1,'FieldsTable']]],
  ['method_5finfo',['method_info',['../struct_frame.html#a4dbf8107ea01f748582bb060aa299628',1,'Frame']]],
  ['methodarea',['methodArea',['../struct_environment.html#a1c73c41c6c38e7e67ea22f6d59044852',1,'Environment']]],
  ['methodref',['Methodref',['../structconst_pool.html#aedc243e8e674b59f15d83255f4fff7f6',1,'constPool']]],
  ['methods',['methods',['../structarq_class.html#a849a70430b6245a2cc8b43a2516c5f00',1,'arqClass']]],
  ['methods_5fcount',['methods_count',['../structarq_class.html#a0cdd803ff7b2a6a229c048bb51f1febc',1,'arqClass']]],
  ['minor_5fversion',['minor_version',['../structarq_class.html#a90b447e4eea035e1dd5fb45360a6a09f',1,'arqClass']]]
];
