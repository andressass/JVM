var searchData=
[
  ['javaclass',['JavaClass',['../struct_java_class.html',1,'']]]
];
