var searchData=
[
  ['name',['name',['../struct_fields_table.html#a931fde572e99face7e9cd2fbc29cd36e',1,'FieldsTable::name()'],['../struct_class_table.html#acd5b84c549aa0dc5b79750c0fa8525be',1,'ClassTable::name()']]],
  ['name_5fand_5ftype_5findex',['name_and_type_index',['../structconst_pool.html#a3dde2ae699efaa1736b684038ea4f3de',1,'constPool']]],
  ['name_5findex',['name_index',['../structconst_pool.html#af3f5f8cd6fcae23720d11786466944e1',1,'constPool::name_index()'],['../structfield_and_method.html#ac636d7076db5a2ce9891613be8ad9b00',1,'fieldAndMethod::name_index()']]],
  ['nameandtype',['NameAndType',['../structconst_pool.html#a727268ed0e1405a5eaab1aa5ad3cba74',1,'constPool']]],
  ['new',['New',['../_i___i_n_s_t_o_b_j_a_n_d_i_n_v_o_k_e_8h.html#a89eca58b188200501fc3af2d17b295fc',1,'New(Environment *environment):&#160;M_INSTOBJANDINVOKE.c'],['../_m___i_n_s_t_o_b_j_a_n_d_i_n_v_o_k_e_8c.html#a949b10b4378c135e0dc21ea174518c7a',1,'New(Environment *environment):&#160;M_INSTOBJANDINVOKE.c']]],
  ['newarray',['newarray',['../_i___i_n_s_t_o_b_j_a_n_d_i_n_v_o_k_e_8h.html#a1fb051fae254af45bc1a1113456f96c2',1,'newarray(Environment *environment):&#160;M_INSTOBJANDINVOKE.c'],['../_m___i_n_s_t_o_b_j_a_n_d_i_n_v_o_k_e_8c.html#a82485bf3564751a58743babf35a236db',1,'newarray(Environment *environment):&#160;M_INSTOBJANDINVOKE.c']]],
  ['newjavaarray',['newJavaArray',['../_j_a_v_a_a_r_r_a_y_8h.html#a469e146f208b829f565844b6d3f5eb04',1,'newJavaArray(u1 n_type, u2 n_length):&#160;JAVAARRAY.c'],['../_j_a_v_a_a_r_r_a_y_8c.html#a4de853ef25bd07cb6ec7636d077e9b86',1,'newJavaArray(u1 n_atype, u2 n_count):&#160;JAVAARRAY.c']]],
  ['newjavastring',['newJavaString',['../_j_a_v_a_s_t_r_i_n_g_8h.html#a45da5085f5f1b479a603f4985ef37db9',1,'newJavaString(const wchar_t *string):&#160;JAVASTRING.c'],['../_j_a_v_a_s_t_r_i_n_g_8c.html#a99138536d94869942bd6e5097ebaf23e',1,'newJavaString(const wchar_t *string):&#160;JAVASTRING.c']]],
  ['newmethodarea',['newMethodArea',['../_i___m_e_m_o_r_y_u_n_i_t_8h.html#a2005a0f5f48b7bf3cdd454be1fdd7bfd',1,'newMethodArea():&#160;M_OPMETHODAREA.c'],['../_m___o_p_m_e_t_h_o_d_a_r_e_a_8c.html#a8b020a9f584309b21d63ace175a676b0',1,'newMethodArea():&#160;M_OPMETHODAREA.c']]],
  ['newobjectfromclass',['newObjectFromClass',['../_i___m_e_m_o_r_y_u_n_i_t_8h.html#a1fc19115ce87779c2a341dd56b5a8db1',1,'newObjectFromClass(const char *className, Environment *environment):&#160;M_OPMETHODAREA.c'],['../_m___o_p_m_e_t_h_o_d_a_r_e_a_8c.html#a16be39ddddc84f01fc139d178c1ccb62',1,'newObjectFromClass(const char *className, Environment *environment):&#160;M_OPMETHODAREA.c']]],
  ['newthread',['newThread',['../_i___m_e_m_o_r_y_u_n_i_t_8h.html#aab75258123f0973cefa41b0154c5d807',1,'newThread():&#160;M_OPTHREAD.c'],['../_m___o_p_t_h_r_e_a_d_8c.html#af6089452d2ad55a58ccf834d4b73e1af',1,'newThread():&#160;M_OPTHREAD.c']]],
  ['next',['next',['../struct_object_list.html#a2e433d18d52a5cd2b3f90651157fdb23',1,'ObjectList::next()'],['../struct_v_m_stack.html#ab4cf67571dfab96182dfd57bf6037d6b',1,'VMStack::next()']]],
  ['nextstack',['nextStack',['../struct_operand_stack.html#a965579f06932f8c57ad8cf660fd0b755',1,'OperandStack']]],
  ['nop',['nop',['../_i___i_n_s_t_l_o_a_d_s_t_o_r_a_g_e_8h.html#af6bfa0d22b6d806a189e7626aacaad8d',1,'nop(Environment *environment):&#160;M_INSTLOADSTORAGE.c'],['../_m___i_n_s_t_l_o_a_d_s_t_o_r_a_g_e_8c.html#af40e4bddc820c7f86fa6c7bc59761e43',1,'nop(Environment *environment):&#160;M_INSTLOADSTORAGE.c']]],
  ['nullpointerexception',['NullPointerException',['../_i___e_x_c_e_p_t_i_o_n_8h.html#a07358c71ce3e62a9e4069c0122cbf43e',1,'I_EXCEPTION.h']]],
  ['number_5fof_5fexceptions',['number_of_exceptions',['../struct_exception_attribute.html#a389b17447aa3278771d0649f1df66e69',1,'ExceptionAttribute']]]
];
