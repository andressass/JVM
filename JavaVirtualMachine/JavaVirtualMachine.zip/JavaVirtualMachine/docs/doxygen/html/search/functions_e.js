var searchData=
[
  ['return_5f',['return_',['../_i___i_n_s_t_r_e_t_u_r_n_8h.html#a88c53007ee32bd15bc306ac41b33756a',1,'return_(Environment *environment):&#160;M_INSTRETURN.c'],['../_m___i_n_s_t_r_e_t_u_r_n_8c.html#ac2e7bbbacfae427495520adbddadb7e2',1,'return_(Environment *environment):&#160;M_INSTRETURN.c']]]
];
