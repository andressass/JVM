var searchData=
[
  ['obter_5fentrada',['obter_entrada',['../_i_p___l_e_c_l_a_s_s_8h.html#a71742ecf4d2dd4d17ec28441f94ba9b1',1,'obter_entrada(const char *nome_arquivo):&#160;MP_LECLASS.c'],['../_m_p___l_e_c_l_a_s_s_8c.html#a925c22cc6ed034861fdb76cc5c19a049',1,'obter_entrada(const char *arq):&#160;MP_LECLASS.c']]]
];
