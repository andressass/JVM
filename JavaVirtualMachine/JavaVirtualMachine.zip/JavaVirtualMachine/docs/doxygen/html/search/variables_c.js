var searchData=
[
  ['object',['object',['../struct_object_list.html#aae49442726f57917e2d6611c62f1e071',1,'ObjectList']]],
  ['objectlist',['objectList',['../struct_java_class.html#af33546b53017ca696367a08e9e30b115',1,'JavaClass']]],
  ['opstk',['opStk',['../struct_frame.html#a0cd2446df36707c236ffaf43844d387a',1,'Frame']]]
];
