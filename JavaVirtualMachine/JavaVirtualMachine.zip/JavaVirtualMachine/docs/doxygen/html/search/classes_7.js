var searchData=
[
  ['npair',['npair',['../structnpair.html',1,'']]]
];
