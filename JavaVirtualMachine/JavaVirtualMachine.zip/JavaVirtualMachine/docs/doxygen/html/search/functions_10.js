var searchData=
[
  ['u1le',['u1Le',['../_i_p___l_e_c_l_a_s_s_8h.html#a0b696ac754cb3058e2b140d8c952f5d5',1,'u1Le(FILE *arquivo):&#160;MP_LECLASS.c'],['../_m_p___l_e_c_l_a_s_s_8c.html#a55fd6e7d9e7bec537a3ca847f3a2b2a2',1,'u1Le(FILE *arquivo):&#160;MP_LECLASS.c']]],
  ['u2le',['u2Le',['../_i_p___l_e_c_l_a_s_s_8h.html#a96774639729d84c50fcd1c9251096c22',1,'u2Le(FILE *arquivo):&#160;MP_LECLASS.c'],['../_m_p___l_e_c_l_a_s_s_8c.html#a56b3c0e3b98330d1b9c1ba5fdd70caff',1,'u2Le(FILE *arquivo):&#160;MP_LECLASS.c']]],
  ['u4le',['u4Le',['../_i_p___l_e_c_l_a_s_s_8h.html#a35f40c339d5d328a776498dddde97abc',1,'u4Le(FILE *arquivo):&#160;MP_LECLASS.c'],['../_m_p___l_e_c_l_a_s_s_8c.html#ac11ab8a1e66b313e4d66385c4a22c107',1,'u4Le(FILE *arquivo):&#160;MP_LECLASS.c']]],
  ['u4todouble',['u4ToDouble',['../_i___t_y_p_e_c_o_n_v_e_r_s_i_o_n_8h.html#a876054124c75d44797a9812f9cd4c973',1,'u4ToDouble(u4 high_bytes, u4 low_bytes):&#160;M_TYPECONVERSION.c'],['../_m___t_y_p_e_c_o_n_v_e_r_s_i_o_n_8c.html#a1635f324e84de6fd96505e01968b7333',1,'u4ToDouble(u4 high_bytes, u4 low_bytes):&#160;M_TYPECONVERSION.c']]],
  ['u4tofloat',['u4ToFLoat',['../_i___t_y_p_e_c_o_n_v_e_r_s_i_o_n_8h.html#a10278c8cd5623d003953e21fdc0515c9',1,'u4ToFLoat(u4 bytes):&#160;M_TYPECONVERSION.c'],['../_m___t_y_p_e_c_o_n_v_e_r_s_i_o_n_8c.html#ac1709d62d399fb8ed1300e6b237d4fcc',1,'u4ToFLoat(u4 bytes):&#160;M_TYPECONVERSION.c']]]
];
