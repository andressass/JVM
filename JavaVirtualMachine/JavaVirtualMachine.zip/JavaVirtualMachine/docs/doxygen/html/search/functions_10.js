var searchData=
[
  ['tableswitch',['tableswitch',['../_i___i_n_s_t_c_o_m_p_a_n_d_j_m_p_8h.html#a62fff00c2f8d2834ccc509f47189f11a',1,'tableswitch(Environment *environment):&#160;M_INSTCOMPANDJMP.c'],['../_m___i_n_s_t_c_o_m_p_a_n_d_j_m_p_8c.html#a7fa7ef352b60bfdd34e8717a990ecf1b',1,'tableswitch(Environment *environment):&#160;M_INSTCOMPANDJMP.c']]]
];
