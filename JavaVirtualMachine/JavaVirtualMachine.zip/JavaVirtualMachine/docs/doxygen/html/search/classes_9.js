var searchData=
[
  ['stack',['Stack',['../struct_stack.html',1,'']]],
  ['stringref',['StringRef',['../struct_string_ref.html',1,'']]]
];
