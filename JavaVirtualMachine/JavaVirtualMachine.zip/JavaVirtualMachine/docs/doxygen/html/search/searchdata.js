var indexSectionsWithContent =
{
  0: "abcdefghijlmnoprstuvw",
  1: "acefhjmnostv",
  2: "eijmo",
  3: "abcdefgijlmnoprstuvw",
  4: "abcdefhijlmnoprstuv",
  5: "acefhijmnostuv",
  6: "acdefijlmnopst"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "defines"
};

var indexSectionLabels =
{
  0: "Todos",
  1: "Estruturas de Dados",
  2: "Arquivos",
  3: "Funções",
  4: "Variáveis",
  5: "Definições de Tipos",
  6: "Definições e Macros"
};

