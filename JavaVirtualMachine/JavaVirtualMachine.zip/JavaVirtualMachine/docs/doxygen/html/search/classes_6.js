var searchData=
[
  ['methodarea',['MethodArea',['../struct_method_area.html',1,'']]]
];
