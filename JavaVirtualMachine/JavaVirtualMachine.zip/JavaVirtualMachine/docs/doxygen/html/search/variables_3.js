var searchData=
[
  ['descriptor',['descriptor',['../struct_fields_table.html#aa1cd4a61abe3e42fd3d2ce8e9a692924',1,'FieldsTable']]],
  ['descriptor_5findex',['descriptor_index',['../structconst_pool.html#a09a23db7ae9a3429931f2a5447f9f7fe',1,'constPool::descriptor_index()'],['../structfield_and_method.html#a61c33b04e96966edbfd142eea9992834',1,'fieldAndMethod::descriptor_index()']]],
  ['double',['Double',['../structconst_pool.html#a860c917cdbc43a11bbe5411a3329129a',1,'constPool']]]
];
