var searchData=
[
  ['negativearraysizeexception',['NegativeArraySizeException',['../_i___e_x_c_e_p_t_i_o_n_8h.html#ad9ef74f06140c381223efd70b50328bc',1,'I_EXCEPTION.h']]],
  ['nullpointerexception',['NullPointerException',['../_i___e_x_c_e_p_t_i_o_n_8h.html#a07358c71ce3e62a9e4069c0122cbf43e',1,'I_EXCEPTION.h']]]
];
